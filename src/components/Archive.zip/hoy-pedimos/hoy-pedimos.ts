import { Component, Input } from '@angular/core'
import { Storage } from '@ionic/storage'
// import { IonicPage, NavController, NavParams, Content } from 'ionic-angular'
// import { OrdersProvider } from './../../providers/orders/orders'

/**
 * Generated class for the HoyPedimosComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'app-hoy-pedimos',
  templateUrl: 'hoy-pedimos.html'
})
export class HoyPedimosComponent {
  // @Input('products') products: any[] = []
  products: any[]
  inBasket: number

  constructor(private storage$: Storage) {}
}
